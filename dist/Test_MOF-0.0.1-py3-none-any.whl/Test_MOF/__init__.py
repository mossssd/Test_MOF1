from Test_MOF.A_MOF import Peanut,taste_of_peanut
from Test_MOF.B_MOF import potato

